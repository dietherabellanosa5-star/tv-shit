package com.personaltv.home

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.tv.material3.Icon
import kotlin.math.min
import kotlin.math.roundToInt

/** Soft grounding shadow that is cut out beneath the glass so it never muddies the panel. */
fun Modifier.softShadow(corner: Dp, spread: Dp = 28.dp, alpha: Float = .30f, dy: Dp = 14.dp): Modifier = drawBehind {
    val cr = min(corner.toPx(), size.minDimension / 2f)
    val hole = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(cr))) }
    clipPath(hole, ClipOp.Difference) {
        val steps = 10
        for (i in 1..steps) {
            val f = i / steps.toFloat()
            val g = spread.toPx() * f
            drawRoundRect(
                Color.Black.copy(alpha = alpha / steps * (1.25f - f)),
                topLeft = Offset(-g, -g + dy.toPx()),
                size = Size(size.width + 2 * g, size.height + 2 * g),
                cornerRadius = CornerRadius(cr + g),
            )
        }
    }
}

/**
 * Translucent glass: the scenery behind it is redrawn, aligned to the screen and blurred,
 * then a restrained white tint and a delicate bright edge are laid over it.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    corner: Dp = 36.dp,
    backdrop: Boolean = true,
    strength: Float = 1f,
    content: @Composable BoxScope.() -> Unit,
) {
    val style = LocalGlass.current
    val scenery = LocalBackdrop.current
    val root = LocalRootSize.current
    val density = LocalDensity.current
    val shape = RoundedCornerShape(corner)
    var origin by remember { mutableStateOf(IntOffset.Zero) }
    val tint = style.tint * strength

    Box(
        modifier
            .softShadow(corner)
            .clip(shape)
            .onGloballyPositioned {
                val p = it.positionInRoot()
                origin = IntOffset(p.x.roundToInt(), p.y.roundToInt())
            }
    ) {
        if (backdrop && root != IntSize.Zero) {
            Box(Modifier.matchParentSize()) {
                Box(
                    Modifier
                        .wrapContentSize(Alignment.TopStart, unbounded = true)
                        .requiredSize(with(density) { root.width.toDp() }, with(density) { root.height.toDp() })
                        .offset { IntOffset(-origin.x, -origin.y) }
                        .blur(style.blur, androidx.compose.ui.draw.BlurredEdgeTreatment.Unbounded)
                ) { scenery() }
            }
        }
        Box(
            Modifier.matchParentSize().background(
                Brush.verticalGradient(listOf(Color.White.copy(alpha = tint + .05f), Color.White.copy(alpha = tint)))
            )
        )
        Box(
            Modifier.matchParentSize().border(
                1.dp,
                Brush.verticalGradient(listOf(Color.White.copy(alpha = .50f), Color.White.copy(alpha = .10f), Color.White.copy(alpha = .22f))),
                shape,
            )
        )
        content()
    }
}

/** The shared focus treatment: a gentle spring lift and a thin bright ring. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.glassFocus(
    corner: Dp,
    scale: Float = 1.06f,
    fill: Boolean = false,
    onFocus: (Boolean) -> Unit = {},
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
): Modifier {
    var focused by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (focused) scale else 1f, spring(dampingRatio = 0.78f, stiffness = 260f), label = "lift")
    val r by animateFloatAsState(if (focused) 1f else 0f, tween(260), label = "ring")
    val interaction = remember { MutableInteractionSource() }
    val shape = RoundedCornerShape(corner)
    return this
        .onFocusChanged { focused = it.isFocused; onFocus(it.isFocused) }
        .graphicsLayer { scaleX = s; scaleY = s }
        .drawWithContent {
            if (fill && r > 0f) drawOutline(shape.createOutline(size, layoutDirection, this), Color.White.copy(alpha = .13f * r))
            drawContent()
            if (r > 0f) drawOutline(
                shape.createOutline(size, layoutDirection, this),
                Color.White.copy(alpha = .92f * r),
                style = Stroke(2.5.dp.toPx()),
            )
        }
        .combinedClickable(interactionSource = interaction, indication = null, onLongClick = onLongClick, onClick = onClick)
}

@Composable
fun GlassButton(
    label: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    selected: Boolean = false,
    onClick: () -> Unit,
) {
    val t = LocalType.current
    GlassSurface(
        modifier.glassFocus(28.dp, scale = 1.05f, onClick = onClick),
        corner = 28.dp, backdrop = false, strength = if (selected) 2.4f else 1f,
    ) {
        Row(Modifier.padding(horizontal = 24.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(icon, null, Modifier.size(24.dp), tint = SoftWhite)
                Box(Modifier.size(10.dp))
            }
            Txt(label, t.label)
        }
    }
}
