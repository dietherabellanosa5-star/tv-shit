package com.personaltv.home

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text

val SoftWhite = Color(0xFFF5F7FA)

/** Inter from assets/fonts when present, otherwise the system sans-serif. */
fun interFamily(ctx: Context): FontFamily = try {
    val am = ctx.assets
    val files = am.list("fonts")?.toSet().orEmpty()
    if (!files.containsAll(listOf("Inter-Regular.ttf", "Inter-Medium.ttf", "Inter-SemiBold.ttf"))) {
        FontFamily.SansSerif
    } else FontFamily(
        Font("fonts/Inter-Regular.ttf", am, FontWeight.Normal),
        Font("fonts/Inter-Medium.ttf", am, FontWeight.Medium),
        Font("fonts/Inter-SemiBold.ttf", am, FontWeight.SemiBold),
    )
} catch (_: Exception) {
    FontFamily.SansSerif
}

class HomeType(family: FontFamily) {
    private fun s(size: Int, w: FontWeight, tracking: Double = 0.0, tnum: Boolean = false) = TextStyle(
        fontFamily = family,
        fontSize = size.sp,
        fontWeight = w,
        letterSpacing = tracking.sp,
        fontFeatureSettings = if (tnum) "tnum" else null,
        color = SoftWhite,
    )

    val clock = s(40, FontWeight.Medium, -0.5, tnum = true)
    val clockSuffix = s(18, FontWeight.Medium, 0.4, tnum = true)
    val temp = s(30, FontWeight.Medium, -0.3, tnum = true)
    val title = s(48, FontWeight.SemiBold, -1.0)
    val section = s(24, FontWeight.SemiBold, -0.2)
    val player = s(30, FontWeight.SemiBold, -0.4)
    val body = s(20, FontWeight.Normal)
    val label = s(18, FontWeight.Medium)
    val caption = s(16, FontWeight.Normal, 0.1, tnum = true)
}

class GlassStyle(val tint: Float, val blur: Dp)

val LocalType = staticCompositionLocalOf<HomeType> { error("HomeType not provided") }
val LocalGlass = compositionLocalOf<GlassStyle> { error("GlassStyle not provided") }
val LocalBackdrop = compositionLocalOf<@Composable () -> Unit> { {} }
val LocalRootSize = compositionLocalOf { IntSize.Zero }

@Composable
fun Txt(
    text: String,
    style: TextStyle,
    modifier: Modifier = Modifier,
    alpha: Float = 1f,
    maxLines: Int = 1,
) {
    Text(
        text = text,
        modifier = modifier,
        color = SoftWhite.copy(alpha = alpha),
        style = style,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}
