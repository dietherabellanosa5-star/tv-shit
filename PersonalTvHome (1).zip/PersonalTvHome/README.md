# Personal TV Home — Scenic Glass

A Kotlin + Compose for TV launcher for Android TV / Google TV.

## Open and run
1. Open this folder in Android Studio (Koala or newer). It creates the Gradle wrapper and syncs.
2. Run on an Android TV / Google TV device or emulator (API 26+; real glass blur needs API 31+).
3. Press Home and choose **Personal TV Home** as the default launcher.

## Add before shipping
- **Inter**: put `Inter-Regular.ttf`, `Inter-Medium.ttf`, `Inter-SemiBold.ttf` in `app/src/main/assets/fonts/`.
  Without them the app falls back to system sans-serif.
- **Photography**: drop JPGs into `app/src/main/res/drawable/` named `wallpaper_1.jpg` … `wallpaper_12.jpg`.
  They appear first in Wallpapers. Four built-in painted scenes ship as fallbacks.
- **Music**: Appearance → Music access → enable Personal TV Home. A preview toggle is in the same screen.

## Notes
- Dock tiles use each app's real TV banner. Apps without one show their icon on a color drawn from the icon.
- Hold Select on an app in Apps to add or remove it from the dock.
- Weather uses approximate network location (ipapi.co) and Open-Meteo, no keys.
- Glass: the scenery behind each panel is redrawn, aligned and blurred. Below API 31 blur is skipped and the tint remains.
