package com.personaltv.home

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.core.graphics.drawable.toBitmap

/**
 * One launchable app. [art] is the app's real TV banner when it ships one;
 * otherwise it is the icon, shown over a color derived from that icon.
 */
data class AppEntry(
    val pkg: String,
    val label: String,
    val intent: Intent,
    val art: ImageBitmap,
    val isBanner: Boolean,
    val backdrop: Color,
)

object AppRepository {
    fun load(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        fun query(category: String) =
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(category), 0)

        val found = (query(Intent.CATEGORY_LEANBACK_LAUNCHER) + query(Intent.CATEGORY_LAUNCHER))
            .distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != ctx.packageName }

        return found.mapNotNull { ri ->
            runCatching {
                val ai = ri.activityInfo
                val banner = ai.loadBanner(pm) ?: ai.applicationInfo.loadBanner(pm)
                val bmp = banner?.toBitmap(640, 360) ?: ai.loadIcon(pm).toBitmap(256, 256)
                AppEntry(
                    pkg = ai.packageName,
                    label = ri.loadLabel(pm).toString(),
                    intent = Intent(Intent.ACTION_MAIN)
                        .setClassName(ai.packageName, ai.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED),
                    art = bmp.asImageBitmap(),
                    isBanner = banner != null,
                    backdrop = if (banner != null) Color.Black else iconBackdrop(bmp),
                )
            }.getOrNull()
        }.sortedBy { it.label.lowercase() }
    }

    /** Brand-tinted backdrop that always contrasts with the icon sitting on it. */
    private fun iconBackdrop(b: Bitmap): Color {
        val s = Bitmap.createScaledBitmap(b, 16, 16, true)
        var r = 0.0; var g = 0.0; var bl = 0.0; var w = 0.0
        for (x in 0 until 16) for (y in 0 until 16) {
            val p = s.getPixel(x, y)
            val a = (p ushr 24) / 255.0
            r += ((p shr 16) and 255) * a; g += ((p shr 8) and 255) * a; bl += (p and 255) * a; w += a
        }
        if (w < 1.0) return Color(0xFF1B2230)
        val avg = Color((r / w / 255).toFloat(), (g / w / 255).toFloat(), (bl / w / 255).toFloat())
        val lum = 0.2126f * avg.red + 0.7152f * avg.green + 0.0722f * avg.blue
        return if (lum > 0.55f) lerp(avg, Color.Black, 0.72f) else lerp(avg, Color.White, 0.86f)
    }
}
