package com.personaltv.home

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.app.NotificationManagerCompat

/** Empty on purpose: enabling it is what grants access to active media sessions. */
class MusicListenerService : NotificationListenerService()

class MusicState(
    val title: String,
    val artist: String,
    val art: ImageBitmap?,
    val playing: Boolean,
    private val basePos: Long,
    val duration: Long,
    private val stamp: Long,
) {
    fun position(): Long {
        val p = if (playing) basePos + (SystemClock.elapsedRealtime() - stamp) else basePos
        return if (duration > 0) p.coerceIn(0, duration) else p.coerceAtLeast(0)
    }
}

class MusicController(private val ctx: Context) {
    private var live by mutableStateOf<MusicState?>(null)
    var demoOn by mutableStateOf(false); private set
    private var demoPlaying by mutableStateOf(true)
    private var demoBase by mutableLongStateOf(74_000L)
    private var demoStamp by mutableLongStateOf(SystemClock.elapsedRealtime())
    private val demoArt: ImageBitmap by lazy { makeDemoArt() }

    private var controller: MediaController? = null
    private var cachedKey: String? = null
    private var cachedArt: ImageBitmap? = null
    private val manager = ctx.getSystemService(MediaSessionManager::class.java)
    private val component = ComponentName(ctx, MusicListenerService::class.java)

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }
    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
    }

    val state: MusicState?
        get() = if (demoOn) {
            MusicState("Golden Hour Drift", "Scenic Glass Ensemble", demoArt, demoPlaying, demoBase, 212_000L, demoStamp)
        } else live

    val hasAccess: Boolean
        get() = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun start() {
        stop()
        try {
            manager.addOnActiveSessionsChangedListener(sessionsListener, component)
            pick(manager.getActiveSessions(component))
        } catch (_: SecurityException) {
            live = null // Notification access not granted yet.
        }
    }

    fun stop() {
        runCatching { manager.removeOnActiveSessionsChangedListener(sessionsListener) }
        controller?.unregisterCallback(callback)
        controller = null
    }

    fun setDemo(on: Boolean) {
        demoOn = on
        demoPlaying = true
        demoBase = 74_000L
        demoStamp = SystemClock.elapsedRealtime()
    }

    fun playPause() {
        if (demoOn) {
            val now = SystemClock.elapsedRealtime()
            if (demoPlaying) demoBase += now - demoStamp
            demoStamp = now
            demoPlaying = !demoPlaying
        } else controller?.transportControls?.let { if (live?.playing == true) it.pause() else it.play() }
    }

    fun next() { if (!demoOn) controller?.transportControls?.skipToNext() }
    fun previous() { if (!demoOn) controller?.transportControls?.skipToPrevious() }

    private fun pick(list: List<MediaController>?) {
        controller?.unregisterCallback(callback)
        controller = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        controller?.registerCallback(callback)
        publish()
    }

    private fun publish() {
        val c = controller ?: run { live = null; return }
        val m = c.metadata
        val ps = c.playbackState
        val st = ps?.state ?: PlaybackState.STATE_NONE
        if (m == null || st == PlaybackState.STATE_NONE || st == PlaybackState.STATE_STOPPED) { live = null; return }
        val title = m.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: m.getString(MediaMetadata.METADATA_KEY_TITLE)
        if (title.isNullOrBlank()) { live = null; return }
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE).orEmpty()
        val key = "$title|$artist|${m.getString(MediaMetadata.METADATA_KEY_ALBUM)}"
        val bmp = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        // Reuse the decoded artwork for the same track so the background doesn't re-fade on every update.
        if (key != cachedKey || (cachedArt == null && bmp != null)) {
            cachedKey = key
            cachedArt = bmp?.asImageBitmap()
        }
        live = MusicState(
            title = title,
            artist = artist,
            art = cachedArt,
            playing = st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING,
            basePos = ps?.position ?: 0L,
            duration = m.getLong(MediaMetadata.METADATA_KEY_DURATION),
            stamp = ps?.lastPositionUpdateTime ?: SystemClock.elapsedRealtime(),
        )
    }

    private fun makeDemoArt(): ImageBitmap {
        val size = 640
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(),
            intArrayOf(0xFF2B3A67.toInt(), 0xFFB07BAC.toInt(), 0xFFF2B5A0.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), p)
        p.shader = null
        p.color = 0xFFFFE3BE.toInt()
        canvas.drawCircle(size * 0.68f, size * 0.42f, size * 0.15f, p)
        p.color = 0xFF1F2A48.toInt()
        val path = android.graphics.Path().apply {
            moveTo(0f, size * 0.78f); lineTo(size * 0.3f, size * 0.55f); lineTo(size * 0.55f, size * 0.76f)
            lineTo(size * 0.78f, size * 0.6f); lineTo(size.toFloat(), size * 0.8f)
            lineTo(size.toFloat(), size.toFloat()); lineTo(0f, size.toFloat()); close()
        }
        canvas.drawPath(path, p)
        return bmp.asImageBitmap()
    }
}
