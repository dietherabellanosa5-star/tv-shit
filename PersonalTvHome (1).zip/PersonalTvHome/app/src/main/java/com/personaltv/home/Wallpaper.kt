package com.personaltv.home

import android.content.Context
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import kotlin.math.sin
import kotlin.random.Random

class Scene(
    val name: String,
    val top: Color, val mid: Color, val horizon: Color,
    val sun: Color, val sunX: Float, val sunY: Float,
    val ridges: List<Color>,
    val stars: Boolean = false,
)

val scenes = listOf(
    Scene("Alpine Dusk", Color(0xFF2B3A67), Color(0xFFB07BAC), Color(0xFFF2B5A0), Color(0xFFFFD9B0), .72f, .52f,
        listOf(Color(0xFF8A7BA8), Color(0xFF5D5A86), Color(0xFF3B3F66), Color(0xFF1F2A48))),
    Scene("Glacier Morning", Color(0xFF7FB2D9), Color(0xFFCFE4EE), Color(0xFFF6EBDD), Color(0xFFFFF4D6), .3f, .5f,
        listOf(Color(0xFFB9D0DE), Color(0xFF8FA9C0), Color(0xFF5F7F9C), Color(0xFF37546F))),
    Scene("Desert Ember", Color(0xFF3E2A47), Color(0xFFC4604A), Color(0xFFF4A261), Color(0xFFFFE0A3), .5f, .6f,
        listOf(Color(0xFFB5543F), Color(0xFF8C3F3A), Color(0xFF5E2C35), Color(0xFF34202E))),
    Scene("Midnight Coast", Color(0xFF0B1330), Color(0xFF1D3A6B), Color(0xFF4B7DA8), Color(0xFFE8EEF7), .78f, .28f,
        listOf(Color(0xFF27496F), Color(0xFF1A3556), Color(0xFF11243F), Color(0xFF0A1629)), stars = true),
)

@Composable
fun SceneCanvas(s: Scene, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        drawRect(Brush.verticalGradient(listOf(s.top, s.mid, s.horizon), 0f, size.height * 0.72f))
        val sunCenter = Offset(size.width * s.sunX, size.height * s.sunY)
        drawCircle(
            Brush.radialGradient(listOf(s.sun.copy(alpha = .95f), s.sun.copy(alpha = 0f)), sunCenter, size.minDimension * .5f),
            radius = size.minDimension * .5f, center = sunCenter,
        )
        if (s.stars) {
            val rnd = Random(7)
            repeat(110) {
                drawCircle(Color.White.copy(alpha = .25f + rnd.nextFloat() * .55f), 1f + rnd.nextFloat() * 2.2f,
                    Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height * .5f))
            }
        }
        s.ridges.forEachIndexed { i, c ->
            val base = size.height * (0.56f + i * 0.1f)
            val amp = size.height * (0.16f - i * 0.025f)
            val path = Path().apply {
                moveTo(0f, size.height)
                val steps = 140
                for (k in 0..steps) {
                    val x = size.width * k / steps
                    val t = k / steps.toFloat() * 6.283f
                    val y = base - amp * (0.55f * sin(t * (1.3f + i * .4f) + i * 1.7f) + 0.45f * sin(t * (3.1f + i * .6f) + i * 3.1f) + 1f) / 2f
                    lineTo(x, y)
                }
                lineTo(size.width, size.height)
                close()
            }
            val hazeTop = lerp(c, s.horizon, 0.28f * (s.ridges.size - i) / s.ridges.size)
            drawPath(path, Brush.verticalGradient(listOf(hazeTop, c), startY = base - amp, endY = size.height))
        }
    }
}

/** A selectable wallpaper: a bundled photo (res/drawable/wallpaper_N) or a built-in scene. */
class WallpaperOption(val name: String, val resId: Int?, val scene: Scene?)

fun wallpaperOptions(ctx: Context): List<WallpaperOption> {
    val photos = (1..12).mapNotNull { i ->
        val id = ctx.resources.getIdentifier("wallpaper_$i", "drawable", ctx.packageName)
        if (id != 0) WallpaperOption("Photo $i", id, null) else null
    }
    return photos + scenes.map { WallpaperOption(it.name, null, it) }
}

@Composable
fun WallpaperLayer(o: WallpaperOption, modifier: Modifier = Modifier.fillMaxSize()) {
    if (o.resId != null) Image(painterResource(o.resId), null, modifier, contentScale = ContentScale.Crop)
    else SceneCanvas(o.scene!!, modifier)
}

/** Wallpaper (or blurred album art while music plays) with a light readability shade. Crossfades on change. */
@Composable
fun ScenicBackground(option: WallpaperOption, art: ImageBitmap?, modifier: Modifier = Modifier.fillMaxSize()) {
    Box(modifier) {
        Crossfade(targetState = Pair(art, option), animationSpec = tween(900), label = "background") { (a, o) ->
            if (a != null) {
                Box(Modifier.fillMaxSize()) {
                    Image(a, null, Modifier.fillMaxSize().blur(56.dp), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .32f)))
                }
            } else WallpaperLayer(o)
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    0f to Color.Black.copy(alpha = .30f),
                    .28f to Color.Transparent,
                    .72f to Color.Transparent,
                    1f to Color.Black.copy(alpha = .22f),
                )
            )
        )
    }
}
