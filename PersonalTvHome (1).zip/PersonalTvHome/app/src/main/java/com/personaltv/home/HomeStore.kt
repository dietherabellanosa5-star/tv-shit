package com.personaltv.home

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class SavedTitle(val title: String, val collection: String?)

/** Small persisted store for favorites, appearance and My Space content. */
class HomeStore(context: Context) {
    private val sp = context.getSharedPreferences("personal_tv_home", Context.MODE_PRIVATE)

    var wallpaper by mutableIntStateOf(sp.getInt("wallpaper", 0)); private set
    var tint by mutableIntStateOf(sp.getInt("tint", 1)); private set
    var blur by mutableIntStateOf(sp.getInt("blur", 1)); private set
    var use24h by mutableStateOf(sp.getBoolean("h24", false)); private set
    var fahrenheit by mutableStateOf(sp.getBoolean("fahrenheit", true)); private set

    val favorites = mutableStateListOf<String>().apply {
        sp.getString("favorites", null)?.split('\n')?.filter { it.isNotBlank() }?.let { addAll(it) }
    }
    val collections = mutableStateListOf<String>().apply {
        sp.getString("collections", null)?.split('\n')?.filter { it.isNotBlank() }?.let { addAll(it) }
    }
    val titles = mutableStateListOf<SavedTitle>().apply {
        sp.getString("titles", null)?.split('\n')?.filter { it.isNotBlank() }?.forEach {
            val parts = it.split('\u001F')
            add(SavedTitle(parts[0], parts.getOrNull(1)?.ifBlank { null }))
        }
    }

    fun setWallpaper(i: Int) { wallpaper = i; sp.edit().putInt("wallpaper", i).apply() }
    fun setTint(i: Int) { tint = i; sp.edit().putInt("tint", i).apply() }
    fun setBlur(i: Int) { blur = i; sp.edit().putInt("blur", i).apply() }
    fun setUse24h(v: Boolean) { use24h = v; sp.edit().putBoolean("h24", v).apply() }
    fun setFahrenheit(v: Boolean) { fahrenheit = v; sp.edit().putBoolean("fahrenheit", v).apply() }

    /** First launch only: fills the dock so it is never empty. */
    fun seedFavorites(packages: List<String>) {
        if (sp.contains("favorites")) return
        favorites.addAll(packages)
        saveFavorites()
    }

    fun toggleFavorite(pkg: String) {
        if (!favorites.remove(pkg)) favorites.add(pkg)
        saveFavorites()
    }

    fun addCollection(name: String) {
        val n = name.trim()
        if (n.isEmpty() || collections.contains(n)) return
        collections.add(n)
        sp.edit().putString("collections", collections.joinToString("\n")).apply()
    }

    fun removeCollection(name: String) {
        collections.remove(name)
        for (i in titles.indices) if (titles[i].collection == name) titles[i] = titles[i].copy(collection = null)
        sp.edit().putString("collections", collections.joinToString("\n")).apply()
        saveTitles()
    }

    fun addTitle(title: String, collection: String?) {
        val t = title.trim()
        if (t.isEmpty()) return
        titles.add(0, SavedTitle(t, collection))
        saveTitles()
    }

    fun removeTitle(item: SavedTitle) { titles.remove(item); saveTitles() }

    private fun saveFavorites() = sp.edit().putString("favorites", favorites.joinToString("\n")).apply()
    private fun saveTitles() = sp.edit()
        .putString("titles", titles.joinToString("\n") { it.title + "\u001F" + (it.collection ?: "") }).apply()
}
