package com.personaltv.home

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {
    private lateinit var store: HomeStore
    private lateinit var music: MusicController
    private var resumeTick by mutableIntStateOf(0)
    private var homeSignal by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = HomeStore(applicationContext)
        music = MusicController(applicationContext)
        setContent { PersonalTvHome(store, music, resumeTick, homeSignal) }
    }

    override fun onStart() { super.onStart(); music.start() }
    override fun onStop() { super.onStop(); music.stop() }
    override fun onResume() { super.onResume(); resumeTick++ }

    /** Pressing the Home button while already here returns to the Home screen. */
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); homeSignal++ }
}
