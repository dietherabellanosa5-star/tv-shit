package com.personaltv.home

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.tv.material3.Icon

@Composable
fun ScreenFrame(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val t = LocalType.current
    Column(Modifier.fillMaxSize().padding(start = 72.dp, end = 72.dp, top = 56.dp)) {
        Txt(title, t.title)
        if (subtitle != null) Txt(subtitle, t.body, Modifier.padding(top = 6.dp), alpha = .72f)
        Spacer(Modifier.height(32.dp))
        content()
    }
}

@Composable
fun QuietEmpty(text: String, modifier: Modifier = Modifier) {
    Txt(text, LocalType.current.body, modifier.widthIn(max = 640.dp), alpha = .6f, maxLines = 3)
}

/** Full-artwork grid with the app name beneath each tile. Hold Select to add or remove from the dock. */
@Composable
fun AppGrid(
    apps: List<AppEntry>,
    favorites: List<String>,
    onLaunch: (AppEntry) -> Unit,
    onToggleFavorite: (AppEntry) -> Unit,
    modifier: Modifier = Modifier,
) {
    val t = LocalType.current
    val first = remember { FocusRequester() }
    LaunchedEffect(apps.isNotEmpty()) { first.safeRequest() }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(196.dp),
        modifier = modifier,
        contentPadding = PaddingValues(start = 10.dp, end = 10.dp, top = 12.dp, bottom = 96.dp),
        horizontalArrangement = Arrangement.spacedBy(28.dp),
        verticalArrangement = Arrangement.spacedBy(30.dp),
    ) {
        items(apps, key = { it.pkg }) { app ->
            var focused by remember { mutableStateOf(false) }
            val isFirst = app.pkg == apps.first().pkg
            Column {
                AppTile(
                    app,
                    Modifier.fillMaxWidth().aspectRatio(16f / 9f).then(if (isFirst) Modifier.focusRequester(first) else Modifier),
                    corner = 20.dp,
                    onFocus = { focused = it },
                    onLongClick = { onToggleFavorite(app) },
                    overlay = {
                        if (app.pkg in favorites) {
                            Box(
                                Modifier.align(Alignment.TopEnd).padding(8.dp).size(28.dp).clip(CircleShape)
                                    .background(Color.Black.copy(alpha = .38f))
                            ) { Icon(Icons.Rounded.Star, "In dock", Modifier.align(Alignment.Center).size(18.dp), tint = SoftWhite) }
                        }
                    },
                    onClick = { onLaunch(app) },
                )
                Txt(app.label, t.label, Modifier.padding(top = 12.dp, start = 4.dp), alpha = if (focused) 1f else .78f)
            }
        }
    }
}

@Composable
fun AppsScreen(store: HomeStore, apps: List<AppEntry>, onLaunch: (AppEntry) -> Unit) {
    ScreenFrame("Apps", "Hold Select on an app to add it to or remove it from the dock.") {
        if (apps.isEmpty()) QuietEmpty("No apps found yet.")
        else AppGrid(apps, store.favorites.toList(), onLaunch, { store.toggleFavorite(it.pkg) })
    }
}

@Composable
fun GlassField(
    value: String,
    onValue: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    onDone: () -> Unit = {},
) {
    val t = LocalType.current
    GlassSurface(modifier.widthIn(max = 560.dp).fillMaxWidth(), corner = 28.dp, backdrop = false) {
        Row(Modifier.padding(horizontal = 22.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(icon, null, Modifier.size(26.dp), tint = SoftWhite.copy(alpha = .8f))
                Spacer(Modifier.size(14.dp))
            }
            Box(Modifier.weight(1f)) {
                if (value.isEmpty()) Txt(placeholder, t.body, alpha = .5f)
                BasicTextField(
                    value = value,
                    onValueChange = onValue,
                    singleLine = true,
                    textStyle = t.body,
                    cursorBrush = SolidColor(SoftWhite),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { onDone() }),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
fun SearchScreen(store: HomeStore, apps: List<AppEntry>, onLaunch: (AppEntry) -> Unit) {
    var query by remember { mutableStateOf("") }
    val results = remember(query, apps) {
        if (query.isBlank()) emptyList() else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }
    ScreenFrame("Search") {
        GlassField(query, { query = it }, "Search your apps", icon = Icons.Rounded.Search)
        Spacer(Modifier.height(28.dp))
        when {
            query.isBlank() -> QuietEmpty("Type a name to find an app.")
            results.isEmpty() -> QuietEmpty("Nothing matches “${query.trim()}”.")
            else -> AppGrid(results, store.favorites.toList(), onLaunch, { store.toggleFavorite(it.pkg) })
        }
    }
}

@Composable
fun DiscoverScreen(onOpenApps: () -> Unit, onSearch: () -> Unit) {
    val t = LocalType.current
    ScreenFrame("Discover") {
        Column(Modifier.fillMaxWidth().padding(top = 64.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Rounded.Explore, null, Modifier.size(56.dp), tint = SoftWhite.copy(alpha = .7f))
            Spacer(Modifier.height(20.dp))
            Txt("Nothing to discover yet", t.section)
            Txt(
                "Recommendations show up here once a content source is connected.",
                t.body, Modifier.padding(top = 8.dp).widthIn(max = 560.dp), alpha = .65f, maxLines = 2,
            )
            Spacer(Modifier.height(32.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                GlassButton("Open Apps", icon = Icons.Rounded.Apps, onClick = onOpenApps)
                GlassButton("Search", icon = Icons.Rounded.Search, onClick = onSearch)
            }
        }
    }
}

@Composable
fun MySpaceScreen(store: HomeStore) {
    val t = LocalType.current
    var newTitle by remember { mutableStateOf("") }
    var newCollection by remember { mutableStateOf("") }
    var active by remember { mutableStateOf<String?>(null) }
    val visible = store.titles.filter { active == null || it.collection == active }

    ScreenFrame("My Space", "Saved titles and your collections.") {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 72.dp)) {
            Txt("Saved titles", t.section)
            Spacer(Modifier.height(14.dp))
            GlassField(newTitle, { newTitle = it }, if (active == null) "Save a title" else "Save a title to $active") {
                store.addTitle(newTitle, active); newTitle = ""
            }
            Spacer(Modifier.height(20.dp))
            if (visible.isEmpty()) QuietEmpty("Titles you save will gather here. Hold Select on one to remove it.")
            else LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(vertical = 8.dp, horizontal = 4.dp)) {
                items(visible) { item ->
                    GlassSurface(
                        Modifier.size(260.dp, 120.dp).glassFocus(24.dp, onLongClick = { store.removeTitle(item) }, onClick = {}),
                        corner = 24.dp, backdrop = false, strength = 1.3f,
                    ) {
                        Column(Modifier.padding(20.dp).fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                            Txt(item.title, t.section, maxLines = 2)
                            Txt(item.collection ?: "Not in a collection", t.caption, alpha = .65f)
                        }
                    }
                }
            }

            Spacer(Modifier.height(40.dp))
            Txt("Collections", t.section)
            Spacer(Modifier.height(14.dp))
            GlassField(newCollection, { newCollection = it }, "New collection") {
                store.addCollection(newCollection); newCollection = ""
            }
            Spacer(Modifier.height(20.dp))
            if (store.collections.isEmpty()) QuietEmpty("Group titles into collections like “Weekend movies”.")
            else {
                Txt("Select a collection to filter titles and save new ones into it. Hold Select to delete.", t.caption, alpha = .6f)
                Spacer(Modifier.height(12.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 8.dp, horizontal = 4.dp)) {
                    items(store.collections.toList()) { name ->
                        val count = store.titles.count { it.collection == name }
                        GlassSurface(
                            Modifier.glassFocus(
                                24.dp,
                                onLongClick = { store.removeCollection(name); if (active == name) active = null },
                                onClick = { active = if (active == name) null else name },
                            ),
                            corner = 24.dp, backdrop = false, strength = if (active == name) 2.4f else 1f,
                        ) {
                            Column(Modifier.padding(horizontal = 26.dp, vertical = 18.dp)) {
                                Txt(name, t.label)
                                Txt(if (count == 1) "1 title" else "$count titles", t.caption, alpha = .65f)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WallpapersScreen(store: HomeStore, options: List<WallpaperOption>) {
    val t = LocalType.current
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { first.safeRequest() }
    ScreenFrame("Wallpapers", "Add photos as res/drawable/wallpaper_1 … wallpaper_12 and they appear here first.") {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(28.dp), contentPadding = PaddingValues(10.dp)) {
            items(options.size) { i ->
                val o = options[i]
                Column {
                    Box(
                        Modifier.size(320.dp, 180.dp)
                            .then(if (i == store.wallpaper.coerceIn(0, options.lastIndex)) Modifier.focusRequester(first) else Modifier)
                            .glassFocus(22.dp, onClick = { store.setWallpaper(i) })
                    ) {
                        Box(Modifier.fillMaxSize().clip(RoundedCornerShape(22.dp))) {
                            WallpaperLayer(o)
                            if (i == store.wallpaper) {
                                Box(
                                    Modifier.align(Alignment.TopEnd).padding(10.dp).size(30.dp).clip(CircleShape)
                                        .background(Color.Black.copy(alpha = .4f))
                                ) { Icon(Icons.Rounded.Check, "Selected", Modifier.align(Alignment.Center).size(18.dp), tint = SoftWhite) }
                            }
                        }
                    }
                    Txt(o.name, t.label, Modifier.padding(top = 12.dp, start = 4.dp), alpha = .85f)
                }
            }
        }
    }
}

@Composable
private fun ChoiceRow(label: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val t = LocalType.current
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Txt(label, t.body, Modifier.width(260.dp), alpha = .85f)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            options.forEachIndexed { i, o -> GlassButton(o, selected = i == selected) { onSelect(i) } }
        }
    }
}

fun openNotificationAccess(ctx: Context) {
    runCatching {
        ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

@Composable
fun AppearanceScreen(store: HomeStore, music: MusicController) {
    val ctx = LocalContext.current
    val t = LocalType.current
    ScreenFrame("Appearance", "Everything updates as you choose.") {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 72.dp)) {
            ChoiceRow("Glass tint", listOf("Light", "Balanced", "Deep"), store.tint) { store.setTint(it) }
            ChoiceRow("Glass blur", listOf("Soft", "Medium", "Strong"), store.blur) { store.setBlur(it) }
            ChoiceRow("Clock", listOf("12-hour", "24-hour"), if (store.use24h) 1 else 0) { store.setUse24h(it == 1) }
            ChoiceRow("Temperature", listOf("°F", "°C"), if (store.fahrenheit) 0 else 1) { store.setFahrenheit(it == 0) }
            ChoiceRow("Music player preview", listOf("Off", "On"), if (music.demoOn) 1 else 0) { music.setDemo(it == 1) }
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.width(260.dp)) {
                    Txt("Music access", t.body, alpha = .85f)
                    Txt(if (music.hasAccess) "Allowed" else "Needed to show what’s playing", t.caption, alpha = .6f, maxLines = 2)
                }
                GlassButton("Open access settings") { openNotificationAccess(ctx) }
            }
        }
    }
}
