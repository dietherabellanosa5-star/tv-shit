package com.personaltv.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Star
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.tv.material3.Icon
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

suspend fun FocusRequester.safeRequest() {
    delay(140)
    runCatching { requestFocus() }
}

/** Full-bleed artwork. Real TV banners fill the tile; icon-only apps sit on a color drawn from the icon. */
@Composable
fun AppTile(
    app: AppEntry,
    modifier: Modifier,
    corner: androidx.compose.ui.unit.Dp = 18.dp,
    onFocus: (Boolean) -> Unit = {},
    onLongClick: (() -> Unit)? = null,
    overlay: @Composable BoxScope.() -> Unit = {},
    onClick: () -> Unit,
) {
    Box(modifier.glassFocus(corner, onFocus = onFocus, onLongClick = onLongClick, onClick = onClick)) {
        Box(Modifier.fillMaxSize().clip(RoundedCornerShape(corner))) {
            if (app.isBanner) {
                Image(app.art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Box(
                    Modifier.fillMaxSize().background(Brush.linearGradient(listOf(app.backdrop, app.backdrop.copy(alpha = .86f)))),
                    contentAlignment = Alignment.Center,
                ) {
                    Image(app.art, null, Modifier.fillMaxHeight(.6f).aspectRatio(1f))
                }
            }
            overlay()
        }
    }
}

@Composable
fun ClockView(use24h: Boolean) {
    val t = LocalType.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(60_000 - (now % 60_000) + 50)
        }
    }
    val fmt = remember(use24h) { SimpleDateFormat(if (use24h) "HH:mm" else "h:mm", Locale.getDefault()) }
    val suffix = remember { SimpleDateFormat("a", Locale.getDefault()) }
    Row(verticalAlignment = Alignment.Bottom) {
        Txt(fmt.format(Date(now)), t.clock)
        if (!use24h) Txt(suffix.format(Date(now)), t.clockSuffix, Modifier.padding(start = 6.dp, bottom = 6.dp), alpha = .7f)
    }
}

@Composable
fun WeatherView(weather: Weather?, fahrenheit: Boolean) {
    if (weather == null) return
    val t = LocalType.current
    val degrees = if (fahrenheit) weather.tempC * 9 / 5 + 32 else weather.tempC
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(weather.icon(), null, Modifier.size(34.dp), tint = SoftWhite)
        Spacer(Modifier.size(12.dp))
        Column {
            Txt("${degrees.roundToInt()}°", t.temp)
            if (weather.city.isNotBlank()) Txt(weather.city, t.caption, alpha = .72f)
        }
    }
}

@Composable
fun HomeScreen(
    store: HomeStore,
    apps: List<AppEntry>,
    music: MusicController,
    weather: Weather?,
    onLaunch: (AppEntry) -> Unit,
    onOpenApps: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val favorites = store.favorites.mapNotNull { pkg -> apps.firstOrNull { it.pkg == pkg } }
    val first = remember { FocusRequester() }
    LaunchedEffect(favorites.isNotEmpty()) { first.safeRequest() }

    Box(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 72.dp, end = 72.dp, top = 48.dp),
            verticalAlignment = Alignment.Top,
        ) {
            WeatherView(weather, store.fahrenheit)
            Spacer(Modifier.weight(1f))
            ClockView(store.use24h)
            Spacer(Modifier.size(28.dp))
            GlassSurface(
                Modifier.size(56.dp).glassFocus(28.dp, scale = 1.1f, onClick = onOpenSettings),
                corner = 28.dp, backdrop = false, strength = 1.2f,
            ) {
                Icon(Icons.Rounded.Settings, "Settings", Modifier.align(Alignment.Center).size(28.dp), tint = SoftWhite)
            }
        }

        Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 56.dp), horizontalAlignment = Alignment.Start) {
            music.state?.let { s ->
                MusicPlayerCard(s, music, Modifier.padding(start = 72.dp, bottom = 28.dp))
            }
            GlassSurface(Modifier.padding(horizontal = 72.dp).fillMaxWidth(), corner = 36.dp) {
                Row(Modifier.padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    LazyRow(
                        Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        items(favorites, key = { it.pkg }) { app ->
                            val isFirst = app.pkg == favorites.first().pkg
                            AppTile(
                                app,
                                Modifier.size(144.dp, 84.dp).then(if (isFirst) Modifier.focusRequester(first) else Modifier),
                                onClick = { onLaunch(app) },
                            )
                        }
                    }
                    Spacer(Modifier.size(10.dp))
                    GlassSurface(
                        Modifier.size(84.dp).glassFocus(18.dp, onClick = onOpenApps),
                        corner = 18.dp, backdrop = false, strength = 1.5f,
                    ) {
                        Icon(Icons.Rounded.Apps, "All apps", Modifier.align(Alignment.Center).size(34.dp), tint = SoftWhite)
                    }
                }
            }
        }
    }
}

@Composable
private fun RoundControl(icon: ImageVector, description: String, big: Boolean = false, onClick: () -> Unit) {
    val d = if (big) 64.dp else 52.dp
    GlassSurface(
        Modifier.size(d).glassFocus(d / 2, scale = 1.12f, onClick = onClick),
        corner = d / 2, backdrop = false, strength = if (big) 2.2f else 1.2f,
    ) {
        Icon(icon, description, Modifier.align(Alignment.Center).size(if (big) 34.dp else 28.dp), tint = SoftWhite)
    }
}

private fun fmtTime(ms: Long): String {
    val s = (ms / 1000).toInt()
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun MusicPlayerCard(state: MusicState, music: MusicController, modifier: Modifier = Modifier) {
    val t = LocalType.current
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(state.playing, state.title) {
        while (true) { tick++; delay(500) }
    }
    val position = remember(tick, state) { state.position() }
    val progress = if (state.duration > 0) position / state.duration.toFloat() else 0f

    GlassSurface(modifier.widthIn(max = 820.dp).fillMaxWidth(), corner = 36.dp) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(136.dp).clip(RoundedCornerShape(22.dp)).background(Color.White.copy(alpha = .1f))) {
                if (state.art != null) Image(state.art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Icon(Icons.Rounded.MusicNote, null, Modifier.align(Alignment.Center).size(48.dp), tint = SoftWhite.copy(alpha = .8f))
            }
            Spacer(Modifier.size(28.dp))
            Column(Modifier.weight(1f)) {
                Txt(state.title, t.player)
                if (state.artist.isNotBlank()) Txt(state.artist, t.body, Modifier.padding(top = 2.dp), alpha = .75f)
                Spacer(Modifier.height(18.dp))
                if (state.duration > 0) {
                    Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(Color.White.copy(alpha = .22f))) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(progress.coerceIn(0f, 1f)).clip(CircleShape).background(SoftWhite))
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Txt(fmtTime(position), t.caption, alpha = .7f)
                        Txt(fmtTime(state.duration), t.caption, alpha = .7f)
                    }
                }
            }
            Spacer(Modifier.size(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                RoundControl(Icons.Rounded.SkipPrevious, "Previous") { music.previous() }
                RoundControl(if (state.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (state.playing) "Pause" else "Play", big = true) { music.playPause() }
                RoundControl(Icons.Rounded.SkipNext, "Next") { music.next() }
            }
        }
    }
}
