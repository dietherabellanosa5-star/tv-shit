package com.personaltv.home

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Search
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.tv.material3.Icon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

enum class Route(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Rounded.Home),
    Discover("Discover", Icons.Rounded.Explore),
    MySpace("My Space", Icons.Rounded.Bookmark),
    Apps("Apps", Icons.Rounded.Apps),
    Search("Search", Icons.Rounded.Search),
    Wallpapers("Wallpapers", Icons.Rounded.Image),
    Appearance("Appearance", Icons.Rounded.Palette),
}

private val dockPriority = listOf(
    "com.google.android.youtube.tv", "com.netflix.ninja", "com.amazon.amazonvideo.livingroom",
    "com.disney.disneyplus", "com.hulu.livingroomplus", "com.spotify.tv.android", "com.plexapp.android",
    "com.google.android.youtube.tvmusic", "com.apple.atve.androidtv.appletv",
)

@Composable
fun PersonalTvHome(store: HomeStore, music: MusicController, resumeTick: Int, homeSignal: Int) {
    val ctx = LocalContext.current
    val focusManager = LocalFocusManager.current
    val type = remember { HomeType(interFamily(ctx)) }

    var apps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    LaunchedEffect(resumeTick) {
        apps = withContext(Dispatchers.Default) { AppRepository.load(ctx) }
        store.seedFavorites(
            apps.sortedBy { dockPriority.indexOf(it.pkg).let { i -> if (i < 0) 999 else i } }.take(10).map { it.pkg }
        )
    }

    var weather by remember { mutableStateOf<Weather?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            weather = WeatherRepository.fetch() ?: weather
            delay(30 * 60_000L)
        }
    }

    var route by remember { mutableStateOf(Route.Home) }
    var settingsOpen by remember { mutableStateOf(false) }
    LaunchedEffect(homeSignal) { route = Route.Home; settingsOpen = false }
    BackHandler(enabled = settingsOpen || route != Route.Home) {
        if (settingsOpen) settingsOpen = false else route = Route.Home
    }

    var wasOpen by remember { mutableStateOf(false) }
    LaunchedEffect(settingsOpen) {
        if (wasOpen && !settingsOpen) { delay(60); runCatching { focusManager.moveFocus(FocusDirection.Next) } }
        wasOpen = settingsOpen
    }

    val options = remember { wallpaperOptions(ctx) }
    val option = options[store.wallpaper.coerceIn(0, options.lastIndex)]
    val glass = GlassStyle(
        tint = listOf(.08f, .13f, .20f)[store.tint.coerceIn(0, 2)],
        blur = listOf(14.dp, 26.dp, 42.dp)[store.blur.coerceIn(0, 2)],
    )
    val art = music.state?.art
    val scenery: @Composable () -> Unit = { ScenicBackground(option, art) }
    var rootSize by remember { mutableStateOf(IntSize.Zero) }

    fun launch(app: AppEntry) { runCatching { ctx.startActivity(app.intent) } }
    fun go(r: Route) { settingsOpen = false; route = r }

    CompositionLocalProvider(
        LocalType provides type,
        LocalGlass provides glass,
        LocalBackdrop provides scenery,
        LocalRootSize provides rootSize,
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black).onSizeChanged { rootSize = it }) {
            scenery()
            val dim by animateFloatAsState(if (route == Route.Home) 0f else .30f, tween(500), label = "dim")
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))

            Box(Modifier.fillMaxSize().focusProperties { canFocus = !settingsOpen }) {
                AnimatedContent(
                    targetState = route,
                    transitionSpec = {
                        (fadeIn(tween(480, delayMillis = 100)) + scaleIn(tween(480), initialScale = .985f)) togetherWith fadeOut(tween(200))
                    },
                    label = "route",
                ) { r ->
                    when (r) {
                        Route.Home -> HomeScreen(store, apps, music, weather, ::launch, { go(Route.Apps) }, { settingsOpen = true })
                        Route.Discover -> DiscoverScreen({ go(Route.Apps) }, { go(Route.Search) })
                        Route.MySpace -> MySpaceScreen(store)
                        Route.Apps -> AppsScreen(store, apps, ::launch)
                        Route.Search -> SearchScreen(store, apps, ::launch)
                        Route.Wallpapers -> WallpapersScreen(store, options)
                        Route.Appearance -> AppearanceScreen(store, music)
                    }
                }
            }

            val scrim by animateFloatAsState(if (settingsOpen) .35f else 0f, tween(350), label = "scrim")
            if (scrim > 0f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = scrim)))

            AnimatedVisibility(
                visible = settingsOpen,
                modifier = Modifier.align(Alignment.CenterEnd),
                enter = slideInHorizontally(spring(dampingRatio = .86f, stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn(tween(300)),
                exit = slideOutHorizontally(tween(280)) { it } + fadeOut(tween(220)),
            ) {
                SettingsPanel(onNavigate = ::go, onChromecast = {
                    runCatching { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                })
            }
        }
    }
}

@Composable
private fun SettingsPanel(onNavigate: (Route) -> Unit, onChromecast: () -> Unit) {
    val t = LocalType.current
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { first.safeRequest() }
    GlassSurface(Modifier.padding(24.dp).width(440.dp).fillMaxHeight(), corner = 40.dp) {
        Column(Modifier.padding(horizontal = 24.dp, vertical = 32.dp)) {
            Txt("Settings", t.section, Modifier.padding(start = 12.dp, bottom = 20.dp))
            SettingsRow(Icons.Rounded.Cast, "Chromecast settings", "Network, display, accounts and more", Modifier.focusRequester(first), onChromecast)
            Spacer(Modifier.height(14.dp))
            Route.entries.forEach { r -> SettingsRow(r.icon, r.label, null, Modifier) { onNavigate(r) } }
        }
    }
}

@Composable
private fun SettingsRow(icon: ImageVector, title: String, subtitle: String?, modifier: Modifier, onClick: () -> Unit) {
    val t = LocalType.current
    Row(
        modifier.fillMaxWidth().height(if (subtitle != null) 76.dp else 62.dp)
            .glassFocus(20.dp, scale = 1.02f, fill = true, onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, Modifier.size(28.dp), tint = SoftWhite)
        Spacer(Modifier.width(18.dp))
        Column {
            Txt(title, t.label)
            if (subtitle != null) Txt(subtitle, t.caption, alpha = .65f)
        }
    }
}
