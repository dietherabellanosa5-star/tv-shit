package com.personaltv.home

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.NightsStay
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.WbCloudy
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Weather(val city: String, val tempC: Double, val code: Int, val isDay: Boolean) {
    fun icon(): ImageVector = when (code) {
        0 -> if (isDay) Icons.Rounded.WbSunny else Icons.Rounded.NightsStay
        1, 2, 3 -> Icons.Rounded.WbCloudy
        45, 48 -> Icons.Rounded.Cloud
        in 51..67, in 80..82 -> Icons.Rounded.WaterDrop
        in 71..77, 85, 86 -> Icons.Rounded.AcUnit
        in 95..99 -> Icons.Rounded.Bolt
        else -> Icons.Rounded.Cloud
    }
}

/** Approximate location from the network, then current conditions from Open-Meteo. No API keys. */
object WeatherRepository {
    suspend fun fetch(): Weather? = withContext(Dispatchers.IO) {
        runCatching {
            val loc = JSONObject(get("https://ipapi.co/json/"))
            val lat = loc.getDouble("latitude")
            val lon = loc.getDouble("longitude")
            val w = JSONObject(
                get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code,is_day")
            ).getJSONObject("current")
            Weather(
                city = loc.optString("city"),
                tempC = w.getDouble("temperature_2m"),
                code = w.getInt("weather_code"),
                isDay = w.getInt("is_day") == 1,
            )
        }.getOrNull()
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }
}
